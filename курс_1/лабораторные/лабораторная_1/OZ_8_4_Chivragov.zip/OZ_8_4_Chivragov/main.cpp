#include <iostream>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <algorithm>
#include <windows.h>
using namespace std;


struct Node {
    int data;
    Node* up;
    Node* down;
    Node* left;
    Node* right;
};

int main()
{
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
    srand((unsigned)time(0));

    int M, N;
    cout << "Введите количетсво строк M: ";
    cin >> M;
    cout << "Введите количество столбцов N: ";
    cin >> N;

    if (M <= 0 || N <= 0)
        {
        cout << "Ошибка! Размерность должна быть положительной!" << endl;
        return 1;
        }


    int total = M * N;
    vector<int> values(total);
    for (int i = 0; i < total; i++)
        values[i] = i + 1;


    for (int i = total - 1; i > 0; i--)
        {
        int j = rand() % (i + 1);
        swap(values[i], values[j]);
        }


    vector<vector<Node*>> grid(M, vector<Node*>(N));
    int idx = 0;
    for (int i = 0; i < M; i++)
        for (int j = 0; j < N; j++) {
            grid[i][j] = new Node;
            grid[i][j]->data = values[idx++];
            grid[i][j]->up = grid[i][j]->down = nullptr;
            grid[i][j]->left = grid[i][j]->right = nullptr;
        }


    for (int i = 0; i < M; i++)
        for (int j = 0; j < N; j++) {
            if (i > 0)     grid[i][j]->up    = grid[i - 1][j];
            if (i < M - 1) grid[i][j]->down  = grid[i + 1][j];
            if (j > 0)     grid[i][j]->left  = grid[i][j - 1];
            if (j < N - 1) grid[i][j]->right = grid[i][j + 1];
        }


    cout << "\nПолученная матрица:" << endl;
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++)
            cout.width(5), cout << grid[i][j]->data;
        cout << endl;
    }


    Node* minNode = grid[0][0];
    int minI = 0, minJ = 0;
    for (int i = 0; i < M; i++)
        for (int j = 0; j < N; j++)
            if (grid[i][j]->data < minNode->data)
                {
                minNode = grid[i][j];
                minI = i;
                minJ = j;
                }

    cout << "\nУзел с минимальным значением data-поля:" << endl;
    cout << "Значение : " << minNode->data << endl;
    cout << "Адрес     : " << (void*)minNode << endl;
    cout << "Индексы   : [" << minI << "][" << minJ << "]" << endl;


    for (int i = 0; i < M; i++)
        for (int j = 0; j < N; j++)
            delete grid[i][j];

    return 0;
}