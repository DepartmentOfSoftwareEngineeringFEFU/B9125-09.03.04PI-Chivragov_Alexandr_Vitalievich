#include <iostream>
#include <fstream>
using namespace std;


struct Node {
    char data;      // символ, который храним в узле
    Node* next;     // указатель на следующий узел стека
};

// Указатель на вершину стека. Изначально стек пуст (nullptr)
Node* top = nullptr;

//  Добавление символа в стек
void addToStack(char symvol) {
    Node* newNode = new Node;   // выделяем память под новый узел
    newNode->data = symvol;     // записываем в него символ
    newNode->next = top;        // новый узел ссылается на старую вершину
    top = newNode;              // теперь новая вершина - это наш новый узел
}

//  Извлечение символа из стека
char removeFromStack() {
    char symvol = top->data;    // берём символ с вершины
    Node* temp = top;           // запоминаем адрес вершины, чтобы потом удалить
    top = top->next;            // вершиной теперь становится следующий узел
    delete temp;                // освобождаем память старой вершины
    return symvol;              // возвращаем символ
}

//   Проверка: пуст ли стек
bool isEmpty() {
    return top == nullptr;
}

int main() {
    system("chcp 65001 > nul"); // отображение русского языка

    ifstream file("input.txt");

    if (!file.is_open()) {
        cout << "Не удалось открыть файл input.txt!" << endl;
        return 1;
    }

    // Читаем файл символ за символом и складываем в стек.

    // поэтому при извлечении символы пойдут в обратном порядке.
    char symvol;
    while (file.get(symvol)) {
        addToStack(symvol);
    }
    file.close();


    cout << "Результат: " << endl;
    while (!isEmpty()) {
        cout << removeFromStack();
    }
    cout << endl;

    return 0;
}