#include <iostream>
#include <iomanip>
#include <string>
#include <windows.h>
using namespace std;

int main() {
    SetConsoleOutputCP(CP_UTF8);
    int N, M;
    cout << "Введите число дней в месяце (от 28 до 31): ";
    cin >> N;


    if (N > 31 || N < 28)
    {
        cout << "Ошибка, введенные данные выходят за границы диапазона!";
        return 1;

    }
    cout << "Введите число, на какой день недели будет начинаться месяц(от 1 до 7): ";
    cin >> M;

    if (M > 7 || M < 1)
    {
        cout << "Ошибка, введенные данные выходят за границы диапазона!";
        return 1;
    }

    int K = (M - 1 + N + 6) / 7;

    int month[10][7];


    int day = 1 - (M - 1);
    for (int i = 0; i < K; i++)
        for (int j = 0; j < 7; j++)
            month[i][j] = day++;


    int prevLen = 31;

    // Заголовок
    const string names[7] = {"   Пн   ", " Вт   "," Ср   "," Чт   "," Пт   "," Сб  ","Вс"};
    cout << "\n   ";
    for (int j = 0; j < 7; j++) cout << setw(6) << names[j];
    cout << "\n   ";
    for (int j = 0; j < 7; j++) cout << "------";
    cout << "\n";

    // Вывод календаря
    for (int i = 0; i < K; i++) {
        cout << setw(2) << (i + 1) << " |";
        for (int j = 0; j < 7; j++) {
            int v = month[i][j];
            if (v < 1) {
                // день предыдущего месяца
                int prev = prevLen + v;
                cout << setw(6) << ("[" + to_string(prev) + "]");
            } else if (v > N) {
                // день следующего месяца
                cout << setw(6) << ("[" + to_string(v - N) + "]");
            } else {
                cout << setw(6) << v;
            }
        }
        cout << "\n";
    }
    return 0;
}