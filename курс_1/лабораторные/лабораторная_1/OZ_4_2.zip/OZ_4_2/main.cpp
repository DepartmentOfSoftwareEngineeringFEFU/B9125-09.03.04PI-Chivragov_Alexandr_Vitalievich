#include <iostream>
#include <cstdlib>      // для rand() и srand()
#include <ctime>        // для time() - чтобы каждый запуск был разный


using namespace std;


struct Node {
    int personNumber;
    Node* next;
};


// head - голова (отсюда забираем - обслуживаем)
// tail - хвост (сюда добавляем - ставим в очередь)
Node* head = nullptr;
Node* tail = nullptr;


int nextPersonNumber = 1;

// Постановка в очередь (добавление в хвост)
void addToQueue() {
    Node* newNode = new Node;               // создаём новый узел
    newNode->personNumber = nextPersonNumber;
    newNode->next = nullptr;                 // после хвоста никого нет

    if (head == nullptr) {
        // Очередь была пуста - новый узел сразу и голова, и хвост
        head = newNode;
        tail = newNode;
    } else {
        // Привязываем новый узел к старому хвосту и обновляем хвост
        tail->next = newNode;
        tail = newNode;
    }

    cout << "  -> В очередь встал человек #" << nextPersonNumber << endl;
    nextPersonNumber++;
}

// Обслуживание (удаление из головы)
void serviceFromQueue() {
    if (head == nullptr) {
        cout << "  -> Очередь пуста, обслуживать некого." << endl;
        return;
    }

    Node* temp = head;                       // запоминаем голову для удаления
    cout << "  -> Обслужен человек #" << head->personNumber << endl;
    head = head->next;                       // голова сдвигается на следующего

    if (head == nullptr) {
        // обнуление хвоста
        tail = nullptr;
    }

    delete temp;
}
//  Вывод текущего состояния очереди
void printQueue() {
    if (head == nullptr) {
        cout << "  Очередь: пусто" << endl;
        return;
    }
    cout << "  Очередь: ";
    Node* current = head;
    while (current != nullptr) {
        cout << "#" << current->personNumber;
        if (current->next != nullptr) cout << " -> ";
        current = current->next;
    }
    cout << endl;
}
//  Очистка памяти перед выходом
void clearQueue() {
    while (head != nullptr) {
        Node* temp = head;
        head = head->next;
        delete temp;
    }
    tail = nullptr;
}
int main() {
    system("chcp 65001 > nul");

    srand(time(0));  // «перемешиваем» генератор случайных чисел по времени


    cout << "После каждого шага: Enter - продолжить, q + Enter - выход" << endl << endl;

    while (true) {
        // Случайно выбираем событие: 0 = поставить в очередь, 1 = обслужить
        int action = rand() % 2;

        if (action == 0) {
            cout << "Событие: ПОСТАНОВКА В ОЧЕРЕДЬ" << endl;
            addToQueue();
        } else {
            cout << "Событие: ОБСЛУЖИВАНИЕ" << endl;
            serviceFromQueue();
        }

        printQueue();

        // Остановка процесса
        cout << "> ";
        char choice = cin.get();
        if (choice != '\n') {
            cin.ignore(10000, '\n');
        }
        if (choice == 'q' || choice == 'Q') {
            break;
        }
        cout << endl;
    }

    cout << "\nСимуляция завершена." << endl;
    clearQueue();

    return 0;
}