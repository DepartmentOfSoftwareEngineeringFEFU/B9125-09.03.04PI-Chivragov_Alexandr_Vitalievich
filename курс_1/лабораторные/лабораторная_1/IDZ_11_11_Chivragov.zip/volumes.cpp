#include "volumes.h"
#include <iostream>
#include <cmath>

using namespace std;

const double PI = acos(-1.0);

// ─── Шар ────────────────────────────────────────────────
double sphereVolume(double r) {
    if (r < 0) { cout << "Радиус шара не может быть отрицательным!"; return 0; }
    return (4.0 / 3.0) * PI * r * r * r;
}

// ─── Шаровой сегмент ────────────────────────────────────
double sphericalSegmentVolume(double r, double h) {
    if (r <= 0) { cout << "Радиус шара должен быть положительным!"; return 0; }
    if (h <= 0) { cout << "Высота сегмента должна быть положительной!"; return 0; }
    if (h > 2 * r) { cout << "Высота сегмента не может быть больше диаметра шара!"; return 0; }
    return PI * h * h * (r - h / 3.0);
}

// ─── Шаровой сектор ─────────────────────────────────────
double sphericalSectorVolume(double r, double h) {
    if (r <= 0) { cout << "Радиус шара должен быть положительным!"; return 0; }
    if (h <= 0) { cout << "Высота шапки должна быть положительной!"; return 0; }
    if (h > 2 * r) { cout << "Высота шапки не может быть больше диаметра шара!"; return 0; }
    return (2.0 / 3.0) * PI * r * r * h;
}

// ─── Конус ──────────────────────────────────────────────
double coneVolume(double r, double h) {
    if (r < 0) { cout << "Радиус конуса не может быть отрицательным!"; return 0; }
    if (h <= 0) { cout << "Высота конуса должна быть положительной!"; return 0; }
    return (1.0 / 3.0) * PI * r * r * h;
}

// ─── Усечённый конус ────────────────────────────────────
double truncatedConeVolume(double R, double r, double h) {
    if (R <= 0) { cout << "Радиус большего основания должен быть положительным!"; return 0; }
    if (r < 0)  { cout << "Радиус меньшего основания не может быть отрицательным!"; return 0; }
    if (r > R)  { cout << "Радиус r не должен превышать R!"; return 0; }
    if (h <= 0) { cout << "Высота должна быть положительной!"; return 0; }
    return (1.0 / 3.0) * PI * h * (R * R + R * r + r * r);
}
