#include <iostream>
using namespace std;


// Каждый узел - один участник игры
struct Node {
    char name[50];   // имя участника
    Node* next;      // указатель на СЛЕДУЮЩЕГО в кругу
};


// Добавление участника в кольцо


Node* addToRing(Node* tail, const char* name) {
    Node* newNode = new Node;

    // Копируем имя в узел посимвольно
    int i = 0;
    while (name[i] != '\0' && i < 49) {
        newNode->name[i] = name[i];
        i++;
    }
    newNode->name[i] = '\0';

    if (tail == nullptr) {
        // Первый участник - сам на себя ссылается (кольцо из одного узла)
        newNode->next = newNode;
    } else {
        // Вставляем новый узел между хвостом и головой
        newNode->next = tail->next;   // новый указывает на голову
        tail->next = newNode;          // старый хвост теперь указывает на новый
    }
    return newNode;  // новый узел становится хвостом
}

//  Вывод текущего состава кольца
void printRing(Node* leader) {
    if (leader == nullptr) {
        cout << "  Круг пуст." << endl;
        return;
    }
    cout << "  В кругу: ";
    Node* current = leader;
    do {
        cout << current->name;
        current = current->next;
        if (current != leader) cout << " -> ";
    } while (current != leader);  // идём по кругу, пока не вернёмся к ведущему
    cout << endl;
}

int main() {
    system("chcp 65001 > nul");

    int N, k;
    cout << "Введите количество участников N: ";
    cin >> N;
    cout << "Введите количество слов в считалочке k: ";
    cin >> k;

    // Проверка
    if (N <= k) {
        cout << "Ошибка: по условию задачи должно быть N > k." << endl;
        return 1;
    }
    if (N < 1 || k < 1) {
        cout << "Ошибка: N и k должны быть положительными." << endl;
        return 1;
    }

    //  Создание кольца из N участников
    Node* tail = nullptr;
    for (int i = 0; i < N; i++) {
        char name[50];
        cout << "Введите имя участника #" << (i + 1) << ": ";
        cin >> name;
        tail = addToRing(tail, name);
    }

    cout << endl;
    cout << "Все встали в круг. Начинаем считалочку!" << endl;
    printRing(tail->next);  // tail->next = голова (первый ведущий)
    cout << endl;


    // Изначально ведущий = tail->next (голова), перед ним - tail.
    Node* beforeLeader = tail;
    int remaining = N;

    while (remaining > 1) {

        for (int i = 0; i < k - 1; i++) {
            beforeLeader = beforeLeader->next;
        }

        // Удаляем k-го человека из кольца
        Node* toRemove = beforeLeader->next;
        cout << "Из круга выходит: " << toRemove->name << endl;

        beforeLeader->next = toRemove->next;
        delete toRemove;

        // Ведущим становится тот, кто был следующим за выбывшим


        remaining--;

        // Показываем текущее состояние круга (если есть кто показывать)
        if (remaining > 1) {
            printRing(beforeLeader->next);
        }
        cout << endl;
    }


    cout << "ПОБЕДИТЕЛЬ: " << beforeLeader->next->name << endl;



    delete beforeLeader->next;

    return 0;
}